<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
    <a href="<?php echo e(url('/pdf')); ?>">pdf</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\YDCT_Certificate\resources\views/welcome.blade.php ENDPATH**/ ?>