<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Certificate</title>
	<style type="text/css">
		h2
		{
			text-align: center;
		}
		.box
		{
			width: 100%;
			height: 170px;
			background: #f5f5f5;
			box-sizing: border-box;
			padding:5px 20px;
		}

		.box h4
		{
			font-size: 1.4em;
			text-decoration: underline;
			font-weight: bold;

		}

		.box a 
		{
			padding:20px 40px;
			background: #00f;
			text-decoration: none;
			color: #fff;
			transition: 0.5s;
			border-radius: 10px;
			font-weight: bold;
		}

		.box a:hover
		{
			background: rgba(255, 0, 0, 0.5);
			color: #000;
		}

	</style>
</head>
<body style="width:60% ; margin: 0 auto;">
	<h2>ICT Knowledge Ltd:</h2>
	<div class="box">
		<h4> Main Centre:</h4>
		<a href="{{url('/mainCentre/office')}}"> Office</a>
		<a href="{{url('/mainCentre/graphich')}}"> Graphich</a>
		<a href="{{url('/mainCentre/hardware')}}"> Hardware</a>
		<a href="{{url('/mainCentre/diploma')}}"> Diploma</a>
	</div>

	<br>
	<hr>
	<br>

	<div class="box">
		<h4> Regional Centre:</h4>
		<a href="{{url('/regionalCentre/office')}}"> Office</a>
		<a href="{{url('/regionalCentre/graphich')}}"> Graphich</a>
		<a href="{{url('/regionalCentre/hardware')}}"> Hardware</a>
		<a href="{{url('/regionalCentre/diploma')}}"> Diploma</a>
		<a href="{{url('/regionalCentre/higherDiploma')}}"> Higher Diploma</a>
	</div>
</body>
</html>