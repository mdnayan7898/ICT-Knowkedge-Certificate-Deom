<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\pdfController;



Route::get('/', [pdfController::class, 'home']);

Route::get('/mainCentre/office', [pdfController::class, 'mainOffice']);
Route::get('/mainCentre/graphich', [pdfController::class, 'mainGraphich']);
Route::get('/mainCentre/hardware', [pdfController::class, 'mainHardware']);
Route::get('/mainCentre/diploma', [pdfController::class, 'mainDiploma']);


Route::get('/regionalCentre/office', [pdfController::class, 'regionalOffice']);
Route::get('/regionalCentre/graphich', [pdfController::class, 'regionalGraphich']);
Route::get('/regionalCentre/hardware', [pdfController::class, 'regionalHardware']);
Route::get('/regionalCentre/diploma', [pdfController::class, 'regionalDiploma']);
Route::get('/regionalCentre/higherDiploma', [pdfController::class, 'regionalHigherDiploma']);

