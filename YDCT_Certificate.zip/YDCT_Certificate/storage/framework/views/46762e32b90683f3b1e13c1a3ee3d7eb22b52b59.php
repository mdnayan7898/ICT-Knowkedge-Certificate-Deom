<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" type="text/css" href="<?php echo e(asset('/support/images/Hardware.png')); ?>">






     <!-- font awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/support/fontawesome/css/all.min.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('/support/fontawesome/js/all.min.js')); ?>"></script>

    <!-- bootstrap CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- jquery -->
    <script type="text/javascript" src="<?php echo e(asset('/support/js/jquery-3.5.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/support/js/axios.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/support/js/popper.min.js')); ?>"></script>

    <!-- Custom js  -->
    <script type="text/javascript" src="<?php echo e(asset('/support/js/custom.js')); ?>"></script>


    <!-- Data table -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/support/data-table-all/datatables.min.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('/support/data-table-all/datatables.min.js')); ?>"></script>
    <script type="text/javascript">
	$(document).ready(function() {
  		$('#dataTable').DataTable();
	});
</script>

<style type="text/css">
	.master_content_box .head_title
	{
		margin:10px 0px;
		padding: 10px;
		text-align: center;
		color: #000080;
		-webkit-text-stroke: 1px #f00;
		background: #f5f5f5;
}
</style>


</head>
<body class="container">
	<div class="master_content_box">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\YDCT_Certificate\resources\views/master.blade.php ENDPATH**/ ?>