<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;


class pdfController extends Controller
{

    public function home(){
        return view('home');
    }
    
    public function mainOffice(){
        $pdf = PDF::loadView('Main_Centre.office');
        return $pdf->stream('Main_Centre_Office.pdf');
    }

    public function mainGraphich(){
        $pdf = PDF::loadView('Main_Centre.graphich');
        return $pdf->stream('Main_Centre_graphich.pdf');
    }

    public function mainHardware(){
        $pdf = PDF::loadView('Main_Centre.hardware');
        return $pdf->stream('Main_Centre_hardware.pdf');
    }

    public function mainDiploma(){
        $pdf = PDF::loadView('Main_Centre.diploma');
        return $pdf->stream('Main_Centre_diploma.pdf');
    }


    public function regionalOffice(){
        $pdf = PDF::loadView('Regional_Centre.office');
        return $pdf->stream('Regional_Centre_Office.pdf');
    }

    public function regionalGraphich(){
        $pdf = PDF::loadView('Regional_Centre.graphich');
        return $pdf->stream('Regional_Centre_graphich.pdf');
    }

    public function regionalHardware(){
        $pdf = PDF::loadView('Regional_Centre.hardware');
        return $pdf->stream('Regional_Centre_hardware.pdf');
    }

    public function regionalDiploma(){
        $pdf = PDF::loadView('Regional_Centre.diploma');
        return $pdf->stream('Regional_Centre_diploma.pdf');
    }

    public function regionalHigherDiploma(){
        $pdf = PDF::loadView('Regional_Centre.higherDiploma');
        return $pdf->stream('Regional_Centre_diploma.pdf');
    }






}
