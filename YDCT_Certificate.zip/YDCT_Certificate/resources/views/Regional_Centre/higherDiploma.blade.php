<!-- Developed by: Mohammad Yeasin Arfat Nayan -->
<!-- Full Stack Web Developer  -->
<!-- Email: mdnayan7898@gmail.com -->
<!-- Mobile: 01690091590 -->

@php 
	$roll = 214584584;
	$reg = 548512358;
	$issueDate = '31-12-2021';
	$name = 'Mohammad Yeasin Arfat Nayan';
	$fathersName = 'Mohammad Abdul Monuf';
	$mothersName = 'Sultana Razia';
	$coachTitle = 'Higher Diploma in Computer Science';
	$branchName = 'Youth Development Computer Training Centre';
	$branchCode = 'CHI-003';
	$coachFrom = 'January'.'`'.'21';
	$coachTo = 'December'.'`'.'21';
	$result = 'A+';

	$SignatureChairman = 'support/images/Signatures/morshed.png';
	$SignatureDirector = 'support/images/Signatures/Ashak2.png';
	$SignatureExamController = 'support/images/Signatures/morshed.png';
@endphp


<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="text/css" href="../../../public/images/Diploma.png">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>{{$coachTitle}}</title>
	<style type="text/css" media="all">

		@font-face 
		{
	        font-family: 'Commercial';
	        src: url({{ storage_path('fonts\Commercial_Becker_Script_D_Regular.ttf')}}) format("truetype");
  		}

		@page
		{
			margin: 0;
			size:letter landscape;
		}

		.box
		{
			position: relative;
		}

		.box p
		{
			margin: 0;
			padding: 0;
			font-family:'Commercial';
			color: #000;
			font-size: 28px;
			cursor: pointer !important;
			color: #000;
		}

		.box .roll p 
		{
			position: fixed;
            left: 905px;
            top:185px;
            font-size: 24px;
		}

		.box .roll p:before
		{
			content: '{{$roll}}';
			position: absolute;
			color: #000;
			left: -0.2px;
			top: -0.2px;
		}

		.box .roll p:after
		{
			content: '{{$roll}}';
			position: absolute;
			color: #000;
			left: 0.2px;
			top: 0.2px;
		}

		.box .reg p 
		{
			position: fixed;
            left:905px;
            top:223px;
            font-size: 24px;
		}

			.box .reg p:before
		{
			content: '{{$reg}}';
			position: absolute;
			color: #000;
			left: -0.2px;
			top: -0.2px;
		}

		.box .reg p:after
		{
			content: '{{$reg}}';
			position: absolute;
			color: #000;
			left: 0.2px;
			top: 0.2px;
		}

		.box .issueDate p 
		{
			position: fixed;
            left: 905px;
            top:258px;
            font-size: 24px;
		}

			.box .issueDate p:before
		{
			content: '{{$issueDate}}';
			position: absolute;
			color: #000;
			left: -0.2px;
			top: -0.2px;
		}

		.box .issueDate p:after
		{
			content: '{{$issueDate}}';
			position: absolute;
			color: #000;
			left: 0.2px;
			top: 0.2px;
		}

		.box .name p 
		{
			position: fixed;
            left:520px;
            top:293px;
		}

		.box .name p:before
		{
			content: '{{$name}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .name p:after
		{
			content: '{{$name}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .fathersName p 
		{
			position: fixed;
            left:480px;
            top:345px;
		}

		.box .fathersName p:before
		{
			content: '{{$fathersName}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .fathersName p:after
		{
			content: '{{$fathersName}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .mothersName p 
		{
			position: fixed;
            left:480px;
            top:390px;
		}

		.box .mothersName p:before
		{
			content: '{{$mothersName}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .mothersName p:after
		{
			content: '{{$mothersName}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .coachTitle p 
		{
			position: fixed;
            left:555px;
            top:440px;
		}

		.box .coachTitle p:before
		{
			content: '{{$coachTitle}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .coachTitle p:after
		{
			content: '{{$coachTitle}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .branchName p
		{
			position: fixed;
            left:395px;
            top:500px;
            font-size: 21px;
		}

		.box .branchName p:before
		{
			content: '{{$branchName}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .branchName p:after
		{
			content: '{{$branchName}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px
		}

		.box .branchCode p 
		{
			position: fixed;
            left:905px;
            top:500px;
            font-size: 24px;
		}

		.box .branchCode p:before
		{
			content: '{{$branchCode}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .branchCode p:after
		{
			content: '{{$branchCode}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .coachFrom p 
		{
			position: fixed;
            left:370px;
            top:540px;
		}

		.box .coachFrom p:before
		{
			content: '{{$coachFrom}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .coachFrom p:after
		{
			content: '{{$coachFrom}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .coachTo p 
		{
			position: fixed;
            left:580px;
            top:540px;
		}

		.box .coachTo p:before
		{
			content: '{{$coachTo}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .coachTo p:after
		{
			content: '{{$coachTo}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .result p 
		{
			position: fixed;
            left:960px;
            top:540px;
		}

		.box .result p:before
		{
			content: '{{$result}}';
			position: absolute;
			color: #000;
			left: -0.25px;
			top: -0.25px;
		}

		.box .result p:after
		{
			content: '{{$result}}';
			position: absolute;
			color: #000;
			left: 0.25px;
			top: 0.25px;
		}

		.box .QR 
		{
			position: fixed;
           	left: 90px;
            bottom:55px;
            width:110px;
            height: 110px;
		}

		.box .QR img
		{
			width: 100%;
            height: 100%;
		}

		.box .SignatureChairman 
		{
			position: fixed;
			top: 655px;
			left: 580px;
			width: 110px;
			height:60px;
			box-sizing: border-box;
		}
		.box .SignatureChairman img
		{
			width: 100%;
			height: 100%;
		}
		.box .SignatureDirector 
		{
			position: fixed;
			top: 655px;
			left: 850px;
			width: 110px;
			height:60px;
			box-sizing: border-box;
		}
		.box .SignatureDirector img
		{
			width: 100%;
			height: 100%;
		}

		.box .SignatureExamController 
		{
			position: fixed;
			top: 655px;
			left:290pxpx;
			width: 110px;
			height:60px;
			box-sizing: border-box;
		}
		.box .SignatureExamController img
		{
			width: 100%;
			height: 100%;
		}

	</style>
</head>
<body>
	<div class="box">
		<div class="roll">
			<p>{{$roll}}</p>
		</div>

		<div class="reg">
			<p>{{$reg}}</p>
		</div>

		<div class="issueDate">
			<p>{{$issueDate}}</p>
		</div>

		<div class="name">
			<p>{{$name}}</p>
		</div>

		<div class="fathersName">
			<p>{{$fathersName}}</p>
		</div>

		<div class="mothersName">
			<p>{{$mothersName}}</p>
		</div>

		<div class="coachTitle">
			<p>{{$coachTitle}}</p>
		</div>

		<div class="branchName">
			<p>{{$branchName}}</p>
		</div>

		<div class="branchCode">
			<p>{{$branchCode}}</p>
		</div>

		<div class="coachFrom">
			<p>{{$coachFrom}}</p>
		</div>

		<div class="coachTo">
			<p>{{$coachTo}}</p>
		</div>

		<div class="result">
			<p>{{$result}}</p>
		</div>

		<div class="QR">
            <img src="{{asset('support/images/barCode.png')}}">
        </div>

        <div class="SignatureChairman">
        	<img src="{{asset($SignatureChairman)}}">
        </div>

        <div class="SignatureDirector">
        	<img src="{{asset($SignatureDirector)}}">
        </div>

        <div class="SignatureExamController">
        	<img src="{{asset($SignatureExamController)}}">
        </div>
	</div>
</body>
</html>