<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Certificate</title>
	<style type="text/css" media="all">

		@font-face {
	        font-family: 'Commercial';
	        src: url(<?php echo e(storage_path('fonts\Commercial_Becker_Script_D_Regular.ttf')); ?>) format("truetype");
  		}

		@page
		{
			margin: 0;
			size:letter landscape;
		}

		.box
		{
			position: relative;
			/*width: 100%;
			height: 100%;
			box-sizing: border-box;*/
		}

		.box p
		{
			margin: 0;
			padding: 0;
			font-family:'Commercial';
			color: #000;
			text-shadow:-1px -1px 0 #000, 
						1px -1px 0 #000, 
						-1px 1px 0 #000, 
						1px 1px 0 #000;
			-webkit-text-stroke: 1px #f00;
			font-size: 28px;
		}

		.box .roll p 
		{
			position: fixed;
            left: 905px;
            top:185px;
            font-size: 24px;
            box-sizing: border-box;
		}

		.box .reg p 
		{
			position: fixed;
            left:905px;
            top:223px;
            font-size: 24px;
            box-sizing: border-box;
		}

		.box .issueDate p 
		{
			position: fixed;
            left: 905px;
            top:258px;
            font-size: 24px;
            box-sizing: border-box;
		}

		.box .name p 
		{
			position: fixed;
            left:520px;
            top:300px;
            box-sizing: border-box;
		}

		.box .fathersName p 
		{
			position: fixed;
            left:480px;
            top:350px;
            box-sizing: border-box;
		}

		.box .mothersName p 
		{
			position: fixed;
            left:480px;
            top:395px;
            box-sizing: border-box;
		}

		.box .coachTitle p 
		{
			position: fixed;
            left:555px;
            top:445px;
            box-sizing: border-box;
		}

		.box .branchCode p 
		{
			 position: fixed;
            left:410px;
            top:500px;
            font-size: 24px;
            box-sizing: border-box;
		}

		.box .coachFrom p 
		{
			position: fixed;
            left:660px;
            top:492px;
            box-sizing: border-box;
		}

		.box .coachTo p 
		{
			position: fixed;
            left:865px;
            top:495px;
            box-sizing: border-box;
		}

		.box .result p 
		{
			position: fixed;
            left:480px;
            top:545px;
            box-sizing: border-box;
		}

		.box .QR 
		{
			position: fixed;
            left: 80px;
            bottom:40px;
            width:110px;
            height: 110px;
		}

		.box .QR img
		{
			width: 100%;
            height: 100%;
		}

	</style>
</head>
<body>
	<div class="box">

		<div class="roll">
			<p>112214584</p>
		</div>

		<div class="reg">
			<p>52145854</p>
		</div>

		<div class="issueDate">
			<p>31-12-2021</p>
		</div>

		<div class="name">
			<p>Mohammad Yeasin Arfat Nayan</p>
		</div>

		<div class="fathersName">
			<p>Mohammad Abdul Monuf</p>
		</div>

		<div class="mothersName">
			<p>Sultana Razia</p>
		</div>

		<div class="coachTitle">
			<p>Diploma in computer Science.</p>
		</div>

		<div class="branchCode">
			<p>CHTR-002</p>
		</div>

		<div class="coachFrom">
			<p>January'21</p>
		</div>

		<div class="coachTo">
			<p>December'21</p>
		</div>

		<div class="result">
			<p>A+</p>
		</div>

		<div class="QR">
            <img src="<?php echo e(asset('')); ?>">
        </div>




	</div>
</body>
</html><?php /**PATH C:\Users\Yeasin Arfat Nayan\Desktop\YDCT_Certificate\resources\views/mypdf.blade.php ENDPATH**/ ?>